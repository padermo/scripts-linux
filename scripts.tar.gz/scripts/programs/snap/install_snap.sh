#!/bin/bash

# Update System
sudo apt update

# Install Snap
if ! command -v snap &> /dev/null; then
  echo "Snap not found, installing..."
  sudo apt install snapd
else
  echo "Snap is already installed."
fi

install_program_snap(){
  local name=$1
  local snap_id=$2

  if snap list | grep -q "$snap_id"; then
    echo "$name is already installed."
  else
    read -p "¿Install $name? [Y/N]: " choice
    if [[ "$choice" == [Yy] ]]; then
      echo "Installing $name..."
      sudo snap install "$snap_id"
      echo "$name install complete."
    elif [[ "$choice" == [Nn] ]]; then
      echo "Skipping $name."
    else
      echo "Option not recognized."
    fi
  fi
}

install_program_snap "Visual Studio Code" "code"
install_program_snap "Postman" "postman"
install_program_snap "Intellij Idea Community" "intellij-idea-community"
install_program_snap "Audacity" "audacity"
install_program_snap "Spotify" "spotify"
install_program_snap "VLC" "vlc"
install_program_snap "Shotcut" "shotcut"
install_program_snap "OBS" "obs-studio"
install_program_snap "Brave" "brave"
install_program_snap "Firefox" "firefox"

echo "Finish."
