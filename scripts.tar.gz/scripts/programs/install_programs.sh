#!/bin/bash

# Define path base
BASE_DIR=$(dirname "$(realpath "$0")")

# Install Programs
echo "Select the method for installing programs:"
echo "1) Flatpak"
echo "2) Snap"
read -p "Enter 1 o 2: " choice

if [ "$choice" == "1" ]; then
  if [ -f "$BASE_DIR/flatpak/install_flatpak.sh" ]; then
    "$BASE_DIR/flatpak/install_flatpak.sh"
  else
    echo "Flatpak installation script not found."
    exit 1
  fi
elif [ "$choice" == "2" ]; then
  if [ -f "$BASE_DIR/snap/install_snap.sh" ]; then
    "$BASE_DIR/snap/install_snap.sh"
  else
    echo "Snap installation script not found."
    exit 1
  fi
else 
  echo "Option not found. Please enter 1 o 2"
  exit 1
fi
