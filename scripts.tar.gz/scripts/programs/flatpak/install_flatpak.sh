#!/bin/bash

# Update System
sudo apt update

# Install Flatpak
if ! command -v flatpak &> /dev/null; then
  echo "Flatpak not found, installing..."
  sudo apt install flatpak
else 
  echo "Flatpak is already installed."
fi

install_program_flatpak(){
  local name=$1
  local flatpak_id=$2

  if flatpak list --app | grep -q "$flatpak_id"; then
    echo "$name is already installed."
  else
    read -p "¿Install $name? [Y/N]: " choice
    if [[ "$choice" == [Yy] ]]; then
      echo "Installing $name..."
      flatpak install flathub "$flatpak_id"
      echo "$name install complete."
    elif [[ "$choice" == [Nn] ]]; then
      echo "Skipping $name."
    else
      echo "Option not recognized."
    fi
  fi
}

install_program_flatpak "Audacity" "org.audacityteam.Audacity"
install_program_flatpak "Visual Studio Code" "com.visualstudio.code"
install_program_flatpak "Postman" "com.getpostman.Postman"
install_program_flatpak "OBS" "com.obsproject.Studio"
install_program_flatpak "Shotcut" "org.shotcut.Shotcut"
install_program_flatpak "Slack" "com.slack.Slack"
install_program_flatpak "VLC" "org.videolan.VLC"
install_program_flatpak "Spotify" "com.spotify.Client"
install_program_flatpak "Firefox" "org.mozilla.firefox"
install_program_flatpak "Google Chrome" "com.google.Chrome"
install_program_flatpak "Brave" "com.brave.Browser"

echo "Finish."
