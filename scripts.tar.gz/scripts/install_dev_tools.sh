#!/bin/bash

# Update System
sudo apt update

# Define path base
BASE_DIR=$(dirname "$(realpath "$0")")

install_tools(){
  local name=$1
  local command=$2

  if ! command -v "$name" &> /dev/null; then
    echo "$name is not installed."
    read -p "¿Do you want to install $name? [Y/N]: " choice
    if [[ "$choice" == [Yy] ]]; then
      sudo apt install -y $command
      echo "$name install."
    elif [[ "$choice" == [Nn] ]]; then
      echo "Skipping $name."
    else
      echo "Option not recognized."
    fi
  else
    echo "$name is already installed."
  fi
}

install_tools "curl" "curl"
install_tools "git" "git"
install_tools "lua" "lua5.4"
install_tools "nvim" "neovim"

# Install Node (nvm)
if ! command -v node &> /dev/null; then
  echo "Node.js is not installed."
  read -p "¿Do you want to install Node.js? [Y/N]: " choice
  if [[ "$choice" == [Yy] ]]; then
    echo "Installing nvm..."
    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.0/install.sh | bash

    # Source nvm script
    export NVM_DIR="$HOME/.nvm"
    [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
    
    echo "Installing Node.js LTS version..."
    nvm install --lts

    echo "Node.js lts install."
    node --version
    npm --version
  elif [[ "$choice" == [Nn] ]]; then
    echo "Skipping Node.js"
  else
    echo "Option not recognized"
  fi
else
  echo "Node.js is already installed."
  node --version
fi

# Install Packer
read -p "¿Do you want to install Packer? [Y/N]: " choice
if [[ "$choice" == [Yy] ]]; then
  if ! command -v git &> /dev/null; then
    git clone --depth 1 https://github.com/wbthomason/packer.nvim ~/.local/share/nvim/site/pack/packer/start/packer.nvim
    echo "Packer install."
  else
    echo "Git is not installed."
  fi
elif [[ "$choice" == [Nn] ]]; then
  echo "Skipping Packer"
else
  echo "Option not recognized"
fi

# Install MongoDB (Ubuntu)
read -p "¿Do you want to install MongoDB? [Y/N]: " choice
if [[ "$choice" == [Yy] ]]; then
  if command -v mongod &> /dev/null; then
    echo "MongoDB is already installed."
    exit 1
  else
    # Install gnupg
    sudo apt-get install gnupg -y
    
    # Import public key
    curl -fsSL https://www.mongodb.org/static/pgp/server-7.0.asc | sudo gpg -o /usr/share/keyrings/mongodb-server-7.0.gpg --dearmor
    
    # Create list file
    echo "deb [ arch=amd64,arm64 signed-by=/usr/share/keyrings/mongodb-server-7.0.gpg ] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/7.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-7.0.list
    
    # Update System
    
    sudo apt-get update
    # Install mongodb-org
    sudo apt-get install -y mongodb-org
    echo "MongoDB install."
  fi
elif [[ "$choice" == [Nn] ]]; then
  echo "Skipping MongoDB."
else
  echo "Option not recognized."
fi

# Install more programs
read -p "¿Do you want to install additional programs? [Y/N]: " choice
if [[ "$choice" == [Yy] ]]; then
  if [ -f "$BASE_DIR/programs/install_programs.sh" ]; then
    "$BASE_DIR/programs/install_programs.sh"
  else
    echo "script not found."
    exit 1
  fi
elif [[ "$choice" == [Nn] ]]; then
  echo "Skipping install more programs."
else
  echo "Option not recognized."
fi
